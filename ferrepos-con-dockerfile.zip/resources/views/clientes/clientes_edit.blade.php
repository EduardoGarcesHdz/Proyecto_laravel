@extends('layouts.app')

@section('contenido')
<div class="flex flex-col md:flex-row items-start gap-8">
    {{-- Formulario de edición --}}
    <div class="w-full md:w-1/2 bg-white p-6 rounded-xl shadow-md">
        <h2 class="text-2xl font-bold text-gray-700 mb-4">Editar Cliente</h2>

        @if(session('mensaje'))
            <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4">
                {{ session('mensaje') }}
            </div>
        @endif

        <form method="POST" action="{{ route('clientes.update', $cliente) }}">
            @csrf
            @method('PUT')

            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-1">Nombre</label>
                <input type="text" name="nombre" value="{{ old('nombre', $cliente->nombre) }}"
                       class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-600" required>
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-1">Teléfono</label>
                <input type="text" name="telefono" value="{{ old('telefono', $cliente->telefono) }}"
                       class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-600" required>
            </div>

            <div class="flex gap-4">
                <button type="submit"
                        class="bg-yellow-600 hover:bg-yellow-700 text-white px-5 py-2 rounded font-semibold">
                    <i data-lucide="save" class="inline-block w-4 h-4 mr-1"></i> Guardar Cambios
                </button>
                <a href="{{ route('clientes.index') }}"
                   class="text-gray-500 hover:underline mt-2 inline-block">← Volver</a>
            </div>
        </form>
    </div>

    {{-- Imagen decorativa --}}
    <div class="w-full md:w-1/2 hidden md:block">
        <img src="{{ asset('img/cliente.png') }}" alt="Cliente" class="rounded-xl shadow-md w-full max-h-[350px] object-cover">
    </div>
</div>
@endsection

