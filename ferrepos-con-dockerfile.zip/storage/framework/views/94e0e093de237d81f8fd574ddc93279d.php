<?php $__env->startSection('contenido'); ?>
<div class="max-w-xl mx-auto bg-white p-8 rounded-2xl shadow-lg">
    <h2 class="text-3xl font-bold text-yellow-700 mb-6 flex items-center gap-2">
        <i data-lucide="plus-circle" class="w-6 h-6"></i> Agregar Producto
    </h2>

    <form method="POST" action="<?php echo e(route('productos.store')); ?>" id="formProducto">
        <?php echo csrf_field(); ?>

        <div class="mb-4">
            <label class="block text-gray-700 font-semibold mb-1">
                <i data-lucide="barcode" class="inline w-4 h-4 mr-1"></i> Código de Barras
            </label>
            <input type="text" name="codigo_barras" class="w-full border px-4 py-2 rounded" required autofocus>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 font-semibold mb-1">
                <i data-lucide="file-text" class="inline w-4 h-4 mr-1"></i> Descripción
            </label>
            <input type="text" name="descripcion" class="w-full border px-4 py-2 rounded" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 font-semibold mb-1">
                <i data-lucide="dollar-sign" class="inline w-4 h-4 mr-1"></i> Precio de Compra
            </label>
            <input type="number" step="0.01" name="precio_compra" class="w-full border px-4 py-2 rounded" required>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 font-semibold mb-1">
                <i data-lucide="tag" class="inline w-4 h-4 mr-1"></i> Precio de Venta
            </label>
            <input type="number" step="0.01" name="precio_venta" class="w-full border px-4 py-2 rounded" required>
        </div>

        <div class="mb-6">
            <label class="block text-gray-700 font-semibold mb-1">
                <i data-lucide="boxes" class="inline w-4 h-4 mr-1"></i> Existencia
            </label>
            <input type="number" step="0.01" name="existencia" class="w-full border px-4 py-2 rounded" required>
        </div>

        <div class="flex justify-between items-center">
            <button type="submit" id="btnGuardar"
                class="bg-yellow-600 hover:bg-yellow-700 text-white font-bold px-6 py-2 rounded flex items-center gap-2 transition-all">
                <i data-lucide="save" class="w-4 h-4"></i> <span>Guardar</span>
            </button>

            <a href="<?php echo e(route('productos.index')); ?>"
                class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold px-6 py-2 rounded flex items-center gap-2">
                <i data-lucide="arrow-left" class="w-4 h-4"></i> Volver
            </a>
        </div>
    </form>
</div>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        lucide.createIcons();

        const form = document.getElementById('formProducto');
        const btn = document.getElementById('btnGuardar');

        form.addEventListener('submit', function () {
            btn.disabled = true;
            btn.innerHTML = `<svg class="animate-spin w-4 h-4 mr-2 text-white" viewBox="0 0 24 24" fill="none">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor"
                    d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
            </svg> Guardando...`;
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\punto-venta\resources\views/productos/productos_create.blade.php ENDPATH**/ ?>