<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Producto;

class ProductoApiController extends Controller
{
    public function index()
    {
        return response()->json(Producto::all());
    }

    public function store(Request $request)
    {
        $request->validate([
            'descripcion' => 'required|string|max:255',
            'codigo_barras' => 'required|string|unique:productos',
            'precio_venta' => 'required|numeric',
            'precio_compra' => 'nullable|numeric',
            'existencia' => 'required|integer|min:0',
        ]);

        $producto = Producto::create($request->all());

        return response()->json(['message' => 'Producto creado correctamente', 'data' => $producto], 201);
    }

    public function show($id)
    {
        $producto = Producto::findOrFail($id);
        return response()->json($producto);
    }

    public function update(Request $request, $id)
    {
        $producto = Producto::findOrFail($id);

        $request->validate([
            'descripcion' => 'sometimes|required|string|max:255',
            'codigo_barras' => 'sometimes|required|string|unique:productos,codigo_barras,' . $producto->id,
            'precio_venta' => 'sometimes|required|numeric',
            'precio_compra' => 'nullable|numeric',
            'existencia' => 'sometimes|required|integer|min:0',
        ]);

        $producto->update($request->all());

        return response()->json(['message' => 'Producto actualizado', 'data' => $producto]);
    }

    public function destroy($id)
    {
        $producto = Producto::findOrFail($id);
        $producto->delete();

        return response()->json(['message' => 'Producto eliminado']);
    }
}


