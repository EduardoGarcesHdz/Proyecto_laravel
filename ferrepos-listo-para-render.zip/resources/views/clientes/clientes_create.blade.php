@extends('layouts.app')

@section('contenido')
<div class="flex flex-col md:flex-row items-center justify-between gap-6">
    {{-- Formulario --}}
    <div class="w-full md:w-1/2">
        <h2 class="text-2xl font-bold text-gray-700 mb-4">Agregar Cliente</h2>

        {{-- Validación --}}
        @if($errors->any())
            <div class="bg-red-100 text-red-800 px-4 py-2 rounded mb-4">
                <ul class="list-disc list-inside">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        {{-- Formulario --}}
        <form method="POST" action="{{ route('clientes.store') }}" class="space-y-4">
            @csrf

            <div>
                <label class="block text-gray-700 font-semibold mb-1" for="nombre">Nombre</label>
                <input type="text" name="nombre" id="nombre" placeholder="Nombre del cliente"
                    class="w-full p-2 border rounded-lg bg-gray-100 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                    required>
            </div>

            <div>
                <label class="block text-gray-700 font-semibold mb-1" for="telefono">Teléfono</label>
                <input type="text" name="telefono" id="telefono" placeholder="Teléfono"
                    class="w-full p-2 border rounded-lg bg-gray-100 focus:outline-none focus:ring-2 focus:ring-yellow-500">
            </div>

            <div class="flex items-center gap-4">
                <button type="submit"
                    class="bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded font-bold">
                    <i data-lucide="user-plus" class="inline-block w-4 h-4 mr-1"></i> Guardar
                </button>

                <a href="{{ route('clientes.index') }}"
                    class="text-gray-600 hover:underline flex items-center">
                    ← Volver al listado
                </a>
            </div>
        </form>
    </div>

    {{-- Imagen decorativa --}}
    <div class="hidden md:block w-full md:w-1/2">
        <img src="{{ asset('img/clientes.png') }}" alt="Ferretería" class="rounded-xl shadow-md">
    </div>
</div>
@endsection

