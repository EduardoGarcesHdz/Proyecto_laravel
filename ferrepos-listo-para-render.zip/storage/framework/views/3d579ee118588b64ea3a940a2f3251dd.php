<?php $__env->startSection('contenido'); ?>
<h2 class="text-2xl font-bold text-gray-700 mb-4">Ventas</h2>


<?php if(session('mensaje')): ?>
    <div x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 3000)"
         class="bg-green-100 border border-green-400 text-green-800 px-4 py-2 rounded mb-4"
         x-transition>
        <?php echo e(session('mensaje')); ?>

    </div>
<?php endif; ?>


<form method="GET" action="<?php echo e(route('ventas.index')); ?>" class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
    <input type="date" name="fecha" value="<?php echo e(request('fecha')); ?>" class="border rounded px-3 py-2" placeholder="Fecha">

    <input type="text" name="cliente" value="<?php echo e(request('cliente')); ?>" class="border rounded px-3 py-2" placeholder="Nombre del cliente">

    <div class="flex gap-2">
        <button type="submit" class="bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded">
            <i data-lucide="filter" class="inline-block w-4 h-4 mr-1"></i> Filtrar
        </button>
        <a href="<?php echo e(route('ventas.index')); ?>" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded">
            Limpiar
        </a>
    </div>
</form>


<?php if($ventas->isEmpty()): ?>
    <p class="text-gray-600">No hay ventas registradas.</p>
<?php else: ?>
    <div class="overflow-x-auto">
        <table class="min-w-full bg-white rounded-xl shadow">
            <thead class="bg-yellow-500 text-white">
                <tr>
                    <th class="py-3 px-4 text-left">Fecha</th>
                    <th class="py-3 px-4 text-left">Cliente</th>
                    <th class="py-3 px-4 text-left">Total</th>
                    <th class="py-3 px-4 text-left">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="py-2 px-4"><?php echo e($venta->created_at->format('d/m/Y H:i')); ?></td>
                        <td class="py-2 px-4"><?php echo e($venta->cliente->nombre); ?></td>
                        <td class="py-2 px-4">$<?php echo e(number_format($venta->total, 2)); ?></td>
                        <td class="py-2 px-4 flex flex-wrap gap-2">
                            <a href="<?php echo e(route('ventas.ticket', $venta->id)); ?>"
                               class="bg-yellow-600 hover:bg-yellow-700 text-white px-3 py-1 rounded text-sm"
                               target="_blank">Ticket</a>

                            <a href="<?php echo e(route('ventas.pdf', $venta->id)); ?>"
                               class="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm"
                               target="_blank">Factura</a>

                            <a href="<?php echo e(route('ventas.show', $venta->id)); ?>"
                               class="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm">
                               Detalles</a>

                            <form method="POST" action="<?php echo e(route('ventas.destroy', $venta->id)); ?>"
                                  onsubmit="return confirm('¿Seguro que deseas eliminar esta venta?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-sm">
                                    Eliminar
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\punto-venta\resources\views/ventas/ventas_index.blade.php ENDPATH**/ ?>