<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>FerrePOS - Punto de Venta para Ferretería</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">

    
    <script src="https://cdn.tailwindcss.com"></script>
    
    
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">

    
    <script src="https://unpkg.com/lucide@latest"></script>

    
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-gray-100 font-['Roboto']">

    
    <header class="bg-yellow-600 text-white p-4 shadow-md">
        <div class="container mx-auto flex flex-col md:flex-row justify-between md:items-center gap-2">
            <div class="flex items-center gap-2">
                <img src="<?php echo e(asset('logo.png')); ?>" alt="Logo Ferretería" class="h-9 w-9 rounded-full shadow bg-white object-cover" />
                <div>
                    <h1 class="text-2xl font-bold">FerrePOS</h1>
                    <?php if(auth()->guard()->check()): ?>
                        <span class="text-xs bg-yellow-800 px-2 py-1 rounded-full inline-block mt-1">
                            Rol: <?php echo e(Auth::user()->rol); ?>

                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <nav class="space-x-4 text-sm md:text-base text-right">
                <?php if(auth()->guard()->check()): ?>
                    <a href="/" class="hover:underline">Inicio</a>
                    <a href="/productos" class="hover:underline">Productos</a>
                    <a href="/vender" class="hover:underline">Vender</a>
                    <a href="/ventas" class="hover:underline">Ventas</a>
                    <?php if(Auth::user()->rol === 'admin'): ?>
                        <a href="/usuarios" class="hover:underline">Usuarios</a>
                    <?php endif; ?>
                    <a href="/logout" class="hover:underline text-red-200">Salir</a>
                <?php else: ?>
                    <a href="/" class="hover:underline">Inicio</a>
                    <a href="<?php echo e(route('registro.form')); ?>" class="hover:underline">Registrarse</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    
    <main class="container mx-auto mt-6 p-4 bg-white rounded-xl shadow min-h-[60vh]">
        <?php echo $__env->yieldContent('contenido'); ?>
    </main>

    
    <footer class="text-center p-4 text-gray-500 text-sm">
        © 2025 FerrePOS - Todos los derechos reservados
    </footer>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>

<?php /**PATH C:\laragon\www\punto-venta\resources\views/layouts/app.blade.php ENDPATH**/ ?>