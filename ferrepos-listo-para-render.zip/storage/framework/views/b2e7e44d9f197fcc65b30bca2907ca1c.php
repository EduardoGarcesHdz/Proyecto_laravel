<?php $__env->startSection('contenido'); ?>
<div class="text-center">
    <h2 class="text-3xl font-bold text-gray-700 mb-4">Bienvenido a FerrePOS</h2>
    <p class="text-gray-600 mb-6">Sistema de punto de venta para ferretería</p>
    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <a href="<?php echo e(route('productos.index')); ?>" class="block bg-yellow-200 p-6 rounded-lg shadow hover:shadow-lg transition text-center">
            <i data-lucide="package" class="w-8 h-8 mb-2 text-yellow-700 mx-auto"></i>
            <h3 class="font-semibold text-xl text-gray-800">Inventario</h3>
            <p class="text-sm text-gray-600">Gestión de productos y stock disponible.</p>
        </a>

        
        <a href="<?php echo e(route('ventas.index')); ?>" class="block bg-yellow-200 p-6 rounded-lg shadow hover:shadow-lg transition text-center">
            <i data-lucide="shopping-cart" class="w-8 h-8 mb-2 text-yellow-700 mx-auto"></i>
            <h3 class="font-semibold text-xl text-gray-800">Ventas</h3>
            <p class="text-sm text-gray-600">Registra compras fácilmente con carrito.</p>
        </a>

        
        <a href="<?php echo e(route('ventas.index')); ?>" class="block bg-yellow-200 p-6 rounded-lg shadow hover:shadow-lg transition text-center">
            <i data-lucide="file-text" class="w-8 h-8 mb-2 text-yellow-700 mx-auto"></i>
            <h3 class="font-semibold text-xl text-gray-800">Reportes</h3>
            <p class="text-sm text-gray-600">Consulta facturas y exporta PDFs.</p>
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\punto-venta\resources\views/home.blade.php ENDPATH**/ ?>