<?php $__env->startSection('contenido'); ?>
<h2 class="text-2xl font-bold text-gray-700 mb-4">Detalle de Venta</h2>

<div class="bg-white shadow-md rounded-xl p-6 mb-6">
    <p><strong>Fecha:</strong> <?php echo e($venta->created_at); ?></p>
    <p><strong>Cliente:</strong> <?php echo e($venta->cliente->nombre); ?></p>
</div>

<?php if($venta->productos && count($venta->productos) > 0): ?>
    <table class="min-w-full bg-white shadow rounded-xl overflow-hidden mb-4">
        <thead class="bg-yellow-500 text-white">
            <tr>
                <th class="py-3 px-4 text-left">Producto</th>
                <th class="py-3 px-4 text-left">Cantidad</th>
                <th class="py-3 px-4 text-left">Precio Unitario</th>
                <th class="py-3 px-4 text-left">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $venta->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b hover:bg-gray-50">
                    <td class="py-2 px-4"><?php echo e($producto->descripcion); ?></td>
                    <td class="py-2 px-4"><?php echo e($producto->cantidad); ?></td>
                    <td class="py-2 px-4">$<?php echo e(number_format($producto->precio, 2)); ?></td>
                    <td class="py-2 px-4">$<?php echo e(number_format($producto->precio * $producto->cantidad, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="text-right mt-4">
        <span class="text-lg font-bold text-gray-800">Total: $<?php echo e(number_format($total, 2)); ?></span>
    </div>
<?php else: ?>
    <p class="text-gray-500">No hay productos en esta venta.</p>
<?php endif; ?>

<a href="<?php echo e(route('ventas.index')); ?>"
   class="mt-4 inline-block bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded">
    Volver al listado
</a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\punto-venta\resources\views/ventas/ventas_show.blade.php ENDPATH**/ ?>