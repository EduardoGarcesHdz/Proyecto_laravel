<?php $__env->startSection('contenido'); ?>
<div class="flex flex-col md:flex-row items-start gap-8">
    
    <div class="w-full md:w-1/2 bg-white p-6 rounded-xl shadow-md">
        <h2 class="text-2xl font-bold text-gray-700 mb-4">Editar Cliente</h2>

        <?php if(session('mensaje')): ?>
            <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('clientes.update', $cliente)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-1">Nombre</label>
                <input type="text" name="nombre" value="<?php echo e(old('nombre', $cliente->nombre)); ?>"
                       class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-600" required>
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-1">Teléfono</label>
                <input type="text" name="telefono" value="<?php echo e(old('telefono', $cliente->telefono)); ?>"
                       class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-600" required>
            </div>

            <div class="flex gap-4">
                <button type="submit"
                        class="bg-yellow-600 hover:bg-yellow-700 text-white px-5 py-2 rounded font-semibold">
                    <i data-lucide="save" class="inline-block w-4 h-4 mr-1"></i> Guardar Cambios
                </button>
                <a href="<?php echo e(route('clientes.index')); ?>"
                   class="text-gray-500 hover:underline mt-2 inline-block">← Volver</a>
            </div>
        </form>
    </div>

    
    <div class="w-full md:w-1/2 hidden md:block">
        <img src="<?php echo e(asset('img/cliente.png')); ?>" alt="Cliente" class="rounded-xl shadow-md w-full max-h-[350px] object-cover">
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\punto-venta\resources\views/clientes/clientes_edit.blade.php ENDPATH**/ ?>