<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Venta;
use App\ProductoVendido;

class VentaApiController extends Controller
{
    public function index()
    {
        return response()->json(Venta::with('cliente', 'productos')->get(), 200);
    }

    public function show($id)
    {
        $venta = Venta::with('cliente', 'productos')->find($id);
        if (!$venta) return response()->json(['error' => 'Venta no encontrada'], 404);

        return response()->json($venta);
    }

    public function store(Request $request)
    {
        $venta = new Venta();
        $venta->id_cliente = $request->input('id_cliente');
        $venta->save();

        foreach ($request->input('productos') as $p) {
            ProductoVendido::create([
                'id_venta' => $venta->id,
                'descripcion' => $p['descripcion'],
                'codigo_barras' => $p['codigo_barras'],
                'precio' => $p['precio'],
                'cantidad' => $p['cantidad']
            ]);
        }

        return response()->json(['mensaje' => 'Venta registrada', 'venta_id' => $venta->id], 201);
    }

    public function destroy($id)
    {
        $venta = Venta::find($id);
        if (!$venta) return response()->json(['error' => 'Venta no encontrada'], 404);

        $venta->delete();
        return response()->json(['mensaje' => 'Venta eliminada'], 200);
    }
}
