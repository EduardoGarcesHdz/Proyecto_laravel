<?php

namespace App\Http\Controllers;

use App\Cliente;
use App\Producto;
use App\ProductoVendido;
use App\Venta;
use Illuminate\Http\Request;

class VenderController extends Controller
{
    public function index()
    {
        $total = 0;
        $productos = session('productos', []);
        foreach ($productos as $producto) {
            $total += $producto->cantidad * $producto->precio_venta;
        }

        return view("vender.vender", [
            "total" => $total,
            "clientes" => Cliente::all(),
        ]);
    }

    public function guardar(Request $request)
    {
        $codigo = $request->input('producto');
        $cantidad = $request->input('cantidad', 1);

        $producto = Producto::where("codigo_barras", $codigo)
            ->orWhere("descripcion", "LIKE", "%$codigo%")
            ->first();

        if (!$producto) {
            return redirect()->route("vender.index")->with("mensaje", "Producto no encontrado");
        }

        if ($producto->existencia < $cantidad) {
            return redirect()->route("vender.index")->with("mensaje", "No hay suficiente existencia del producto");
        }

        $productos = session("productos", []);

        $indice = -1;
        foreach ($productos as $i => $p) {
            if ($p->id === $producto->id) {
                $indice = $i;
                break;
            }
        }

        if ($indice !== -1) {
            $productos[$indice]->cantidad += $cantidad;
        } else {
            $producto->cantidad = $cantidad;
            $productos[] = $producto;
        }

        session(["productos" => $productos]);

        return redirect()->route("vender.index")->with("mensaje", "Producto agregado al carrito");
    }

    public function quitarProductoDeVenta(Request $request)
    {
        $indice = $request->post("indice");
        $productos = session("productos", []);
        array_splice($productos, $indice, 1);
        session(["productos" => $productos]);
        return redirect()->route("vender.index");
    }

    public function terminarOCancelarVenta(Request $request)
    {
        if ($request->input("accion") == "terminar") {
            return $this->terminarVenta($request);
        } else {
            return $this->cancelarVenta();
        }
    }

    public function terminarVenta(Request $request)
    {
        $venta = new Venta();
        $venta->id_cliente = $request->input("id_cliente");
        $venta->saveOrFail();

        $idVenta = $venta->id;
        $productos = session("productos", []);

        foreach ($productos as $producto) {
            $productoVendido = new ProductoVendido();
            $productoVendido->fill([
                "id_venta" => $idVenta,
                "descripcion" => $producto->descripcion,
                "codigo_barras" => $producto->codigo_barras,
                "precio" => $producto->precio_venta,
                "cantidad" => $producto->cantidad,
            ]);
            $productoVendido->saveOrFail();

            $productoActualizado = Producto::find($producto->id);
            $productoActualizado->existencia -= $producto->cantidad;
            $productoActualizado->saveOrFail();
        }

        session()->forget("productos");
        return redirect()->route("vender.index")->with("mensaje", "Venta terminada");
    }

    public function cancelarVenta()
    {
        session()->forget("productos");
        return redirect()->route("vender.index")->with("mensaje", "Venta cancelada");
    }
}
