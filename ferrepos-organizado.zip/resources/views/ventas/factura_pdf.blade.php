<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Factura de Venta #{{ $venta->id }}</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 14px; color: #333; }
        .header { display: flex; align-items: center; justify-content: space-between; }
        .logo { height: 60px; }
        .empresa { font-size: 18px; font-weight: bold; color: #222; }
        .datos { margin-top: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #999; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .total { text-align: right; font-weight: bold; margin-top: 10px; }
        .footer { margin-top: 40px; text-align: center; font-size: 12px; color: #666; }
    </style>
</head>
<body>

    <div class="header">
        <img src="{{ public_path('logo.png') }}" class="logo" alt="Logo Ferretería">
        <div class="empresa">
            FerrePOS - Ferretería <br>
            Calle San juan, Col. Centro, Tampico<br>
            Tel: (833) 456 7890
        </div>
    </div>

    <div class="datos">
        <p><strong>Factura #:</strong> {{ $venta->id }}</p>
        <p><strong>Fecha:</strong> {{ $venta->created_at->format('d/m/Y H:i') }}</p>
        <p><strong>Cliente:</strong> {{ $venta->cliente->nombre }}</p>
    </div>

    <table>
        <thead>
            <tr>
                <th>Cantidad</th>
                <th>Producto</th>
                <th>Precio</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($venta->productos as $producto)
                <tr>
                    <td>{{ number_format($producto->cantidad, 2) }}</td>
                    <td>{{ $producto->descripcion }}</td>
                    <td>${{ number_format($producto->precio, 2) }}</td>
                    <td>${{ number_format($producto->cantidad * $producto->precio, 2) }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <p class="total">Total: ${{ number_format($total, 2) }}</p>

    <div class="footer">
        Gracias por su compra<br>
        © 2025 FerrePOS - Todos los derechos reservados
    </div>

</body>
</html>
