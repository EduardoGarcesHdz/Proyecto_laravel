@extends('layouts.app')

@section('contenido')
<h2 class="text-2xl font-bold text-gray-700 mb-4">Detalle de Venta</h2>

<div class="bg-white shadow-md rounded-xl p-6 mb-6">
    <p><strong>Fecha:</strong> {{ $venta->created_at }}</p>
    <p><strong>Cliente:</strong> {{ $venta->cliente->nombre }}</p>
</div>

@if($venta->productos && count($venta->productos) > 0)
    <table class="min-w-full bg-white shadow rounded-xl overflow-hidden mb-4">
        <thead class="bg-yellow-500 text-white">
            <tr>
                <th class="py-3 px-4 text-left">Producto</th>
                <th class="py-3 px-4 text-left">Cantidad</th>
                <th class="py-3 px-4 text-left">Precio Unitario</th>
                <th class="py-3 px-4 text-left">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            @foreach($venta->productos as $producto)
                <tr class="border-b hover:bg-gray-50">
                    <td class="py-2 px-4">{{ $producto->descripcion }}</td>
                    <td class="py-2 px-4">{{ $producto->cantidad }}</td>
                    <td class="py-2 px-4">${{ number_format($producto->precio, 2) }}</td>
                    <td class="py-2 px-4">${{ number_format($producto->precio * $producto->cantidad, 2) }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <div class="text-right mt-4">
        <span class="text-lg font-bold text-gray-800">Total: ${{ number_format($total, 2) }}</span>
    </div>
@else
    <p class="text-gray-500">No hay productos en esta venta.</p>
@endif

<a href="{{ route('ventas.index') }}"
   class="mt-4 inline-block bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded">
    Volver al listado
</a>
@endsection

