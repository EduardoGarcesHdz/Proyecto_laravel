<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ProductoApiController;
use App\Http\Controllers\Api\ClienteApiController;
use App\Http\Controllers\Api\VentaApiController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Estas rutas están protegidas por autenticación si se usa Passport/Sanctum.
| Puedes ajustarlas fácilmente para agregar tokens o scopes.
|
*/

// Ruta de prueba
Route::get('/status', function () {
    return response()->json(['status' => 'OK']);
});

// Agrupar bajo prefijo /api/v1 si deseas versión
Route::prefix('v1')->group(function () {

    // Productos
    Route::get('/productos', [ProductoApiController::class, 'index']);
    Route::post('/productos', [ProductoApiController::class, 'store']);
    Route::get('/productos/{id}', [ProductoApiController::class, 'show']);
    Route::put('/productos/{id}', [ProductoApiController::class, 'update']);
    Route::delete('/productos/{id}', [ProductoApiController::class, 'destroy']);

    // Clientes
    Route::get('/clientes', [ClienteApiController::class, 'index']);
    Route::post('/clientes', [ClienteApiController::class, 'store']);
    Route::get('/clientes/{id}', [ClienteApiController::class, 'show']);
    Route::put('/clientes/{id}', [ClienteApiController::class, 'update']);
    Route::delete('/clientes/{id}', [ClienteApiController::class, 'destroy']);

    // Ventas
    Route::get('/ventas', [VentaApiController::class, 'index']);
    Route::post('/ventas', [VentaApiController::class, 'store']);
    Route::get('/ventas/{id}', [VentaApiController::class, 'show']);
    Route::delete('/ventas/{id}', [VentaApiController::class, 'destroy']);

});

