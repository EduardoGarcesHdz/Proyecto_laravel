<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

use App\Http\Controllers\HomeController;
use App\Http\Controllers\ClientesController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ProductosController;
use App\Http\Controllers\VentasController;
use App\Http\Controllers\VenderController;
use App\Http\Controllers\PDFVentasController;
use App\Http\Controllers\RegistroController;

// Página principal redirige a /home
Route::get('/', function () {
    return redirect()->route('home');
});

// Rutas de autenticación de Laravel
Auth::routes();

// Página principal después de login
Route::get('/home', [HomeController::class, 'index'])->name('home');

// Cierre de sesión
Route::get('/logout', function () {
    Auth::logout();
    return redirect()->route('home');
})->name('logout');

// Rutas protegidas por autenticación (admin y vendedor)
Route::middleware('auth')->group(function () {
    // Todos pueden ver clientes y ventas
    Route::resource('clientes', ClientesController::class);
    Route::resource('ventas', VentasController::class);

    // Funciones específicas de ventas
    Route::get('/ventas/ticket/{venta}', [VentasController::class, 'ticket'])->name('ventas.ticket');
    Route::get('/ventas/pdf/{id}', [PDFVentasController::class, 'generar'])->name('ventas.pdf');

    // Módulo de ventas (carrito)
    Route::get('/vender', [VenderController::class, 'index'])->name('vender.index');
    Route::post('/vender/agregar', [VenderController::class, 'guardar'])->name('vender.agregar');
    Route::delete('/vender/quitar', [VenderController::class, 'quitarProductoDeVenta'])->name('vender.quitar');
    Route::post('/vender/finalizar', [VenderController::class, 'terminarOCancelarVenta'])->name('vender.terminar');
});

// Rutas exclusivas para administradores
Route::middleware(['auth', 'admin'])->group(function () {
    Route::resource('usuarios', UserController::class)->parameters(['usuarios' => 'user']);
    Route::resource('productos', ProductosController::class);

    // Ejemplo: acceso a configuración o dashboard
    Route::view('/admin/configuracion', 'admin.config')->name('admin.config');
});

// Registro personalizado
Route::get('/registro', [RegistroController::class, 'formulario'])->name('registro.form');
Route::post('/registro', [RegistroController::class, 'registrar'])->name('registro.enviar');

// Rutas de prueba (debug)
Route::view('/debug', 'debug');
Route::post('/debug-login', function (Request $request) {
    if (Auth::attempt($request->only('email', 'password'))) {
        return '✅ Login correcto como: ' . Auth::user()->name;
    } else {
        return '❌ Login fallido';
    }
});


