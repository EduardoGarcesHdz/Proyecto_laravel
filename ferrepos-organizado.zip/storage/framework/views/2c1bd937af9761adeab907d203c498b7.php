<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Factura de Venta #<?php echo e($venta->id); ?></title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 14px; color: #333; }
        .header { display: flex; align-items: center; justify-content: space-between; }
        .logo { height: 60px; }
        .empresa { font-size: 18px; font-weight: bold; color: #222; }
        .datos { margin-top: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #999; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .total { text-align: right; font-weight: bold; margin-top: 10px; }
        .footer { margin-top: 40px; text-align: center; font-size: 12px; color: #666; }
    </style>
</head>
<body>

    <div class="header">
        <img src="<?php echo e(public_path('logo.png')); ?>" class="logo" alt="Logo Ferretería">
        <div class="empresa">
            FerrePOS - Ferretería <br>
            Calle San juan, Col. Centro, Tampico<br>
            Tel: (833) 456 7890
        </div>
    </div>

    <div class="datos">
        <p><strong>Factura #:</strong> <?php echo e($venta->id); ?></p>
        <p><strong>Fecha:</strong> <?php echo e($venta->created_at->format('d/m/Y H:i')); ?></p>
        <p><strong>Cliente:</strong> <?php echo e($venta->cliente->nombre); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>Cantidad</th>
                <th>Producto</th>
                <th>Precio</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $venta->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(number_format($producto->cantidad, 2)); ?></td>
                    <td><?php echo e($producto->descripcion); ?></td>
                    <td>$<?php echo e(number_format($producto->precio, 2)); ?></td>
                    <td>$<?php echo e(number_format($producto->cantidad * $producto->precio, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <p class="total">Total: $<?php echo e(number_format($total, 2)); ?></p>

    <div class="footer">
        Gracias por su compra<br>
        © 2025 FerrePOS - Todos los derechos reservados
    </div>

</body>
</html>
<?php /**PATH C:\laragon\www\punto-venta\resources\views/ventas/factura_pdf.blade.php ENDPATH**/ ?>