<?php $__env->startSection('contenido'); ?>
<h2 class="text-2xl font-bold text-gray-700 mb-4">Registrar Venta</h2>


<?php if(session('mensaje')): ?>
    <div 
        x-data="{ show: true }" 
        x-show="show" 
        x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="opacity-0 scale-95"
        x-transition:enter-end="opacity-100 scale-100"
        x-transition:leave="transition ease-in duration-300"
        x-transition:leave-start="opacity-100 scale-100"
        x-transition:leave-end="opacity-0 scale-95"
        x-init="setTimeout(() => show = false, 3000)"
        class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4"
    >
        <?php echo e(session('mensaje')); ?>

    </div>
<?php endif; ?>


<form method="POST" action="<?php echo e(route('vender.agregar')); ?>" class="mb-6">
    <?php echo csrf_field(); ?>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        <input type="text" name="producto" class="border rounded p-2" placeholder="Código de barras o nombre" required>
        <input type="number" name="cantidad" min="1" value="1" class="border rounded p-2" placeholder="Cantidad" required>
        <button type="submit" class="bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded font-semibold">
            <i data-lucide="shopping-bag" class="inline-block w-5 h-5"></i> Agregar al carrito
        </button>
    </div>
</form>


<?php if(session('productos') && count(session('productos')) > 0): ?>
    <table class="min-w-full bg-white shadow-md rounded-xl overflow-hidden mb-4">
        <thead class="bg-yellow-500 text-white">
            <tr>
                <th class="py-3 px-4">Producto</th>
                <th class="py-3 px-4">Cantidad</th>
                <th class="py-3 px-4">Precio</th>
                <th class="py-3 px-4">Total</th>
                <th class="py-3 px-4">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = session('productos'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indice => $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-b hover:bg-gray-50 transition-transform duration-300 hover:scale-[101%]">
                <td class="py-2 px-4"><?php echo e($producto->descripcion); ?></td>
                <td class="py-2 px-4"><?php echo e($producto->cantidad); ?></td>
                <td class="py-2 px-4">$<?php echo e(number_format($producto->precio_venta, 2)); ?></td>
                <td class="py-2 px-4">$<?php echo e(number_format($producto->cantidad * $producto->precio_venta, 2)); ?></td>
                <td class="py-2 px-4">
                    <form method="POST" action="<?php echo e(route('vender.quitar')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="hidden" name="indice" value="<?php echo e($indice); ?>">
                        <button class="text-red-600 hover:underline" onclick="return confirm('¿Quitar producto?')">
                            <i data-lucide="trash-2" class="inline-block w-4 h-4 mr-1"></i> Eliminar
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    
    <div class="text-right mb-4">
        <span class="text-lg font-bold text-gray-700">Total: $<?php echo e(number_format($total, 2)); ?></span>
    </div>

    
    <form method="POST" action="<?php echo e(route('vender.terminar')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="accion" value="terminar">

        <div class="flex items-center gap-3 mb-2">
            <select name="id_cliente" class="border rounded px-2 py-1" required>
                <option value="">-- Selecciona un cliente --</option>
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <a href="<?php echo e(route('clientes.create')); ?>" target="_blank" class="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded text-sm font-semibold">
                + Agregar Cliente
            </a>
        </div>

        <button class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded font-bold">
            <i data-lucide="credit-card"></i> Terminar Venta
        </button>
    </form>

    
    <form method="POST" action="<?php echo e(route('vender.terminar')); ?>" class="mt-2">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="accion" value="cancelar">
        <button class="bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded font-bold">
            <i data-lucide="x-circle"></i> Cancelar
        </button>
    </form>
<?php endif; ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\punto-venta\resources\views/vender/vender.blade.php ENDPATH**/ ?>