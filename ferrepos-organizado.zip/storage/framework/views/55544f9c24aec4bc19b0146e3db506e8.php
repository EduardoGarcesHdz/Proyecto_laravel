<?php $__env->startSection('contenido'); ?>
<h2 class="text-2xl font-bold text-yellow-700 mb-6">Editar Producto</h2>

<div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
    
    <form action="<?php echo e(route('productos.update', $producto->id)); ?>" method="POST" class="bg-white p-6 rounded-xl shadow-md animate-fade-in-up">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4">
            <label class="block text-sm font-semibold text-gray-700 mb-1">Código de Barras</label>
            <input type="text" name="codigo_barras" value="<?php echo e(old('codigo_barras', $producto->codigo_barras)); ?>" class="w-full border px-3 py-2 rounded focus:outline-none focus:ring-2 focus:ring-yellow-600">
        </div>

        <div class="mb-4">
            <label class="block text-sm font-semibold text-gray-700 mb-1">Descripción</label>
            <input type="text" name="descripcion" value="<?php echo e(old('descripcion', $producto->descripcion)); ?>" class="w-full border px-3 py-2 rounded focus:outline-none focus:ring-2 focus:ring-yellow-600">
        </div>

        <div class="mb-4">
            <label class="block text-sm font-semibold text-gray-700 mb-1">Precio de Compra</label>
            <input type="number" step="0.01" name="precio_compra" value="<?php echo e(old('precio_compra', $producto->precio_compra)); ?>" class="w-full border px-3 py-2 rounded focus:outline-none focus:ring-2 focus:ring-yellow-600">
        </div>

        <div class="mb-4">
            <label class="block text-sm font-semibold text-gray-700 mb-1">Precio de Venta</label>
            <input type="number" step="0.01" name="precio_venta" value="<?php echo e(old('precio_venta', $producto->precio_venta)); ?>" class="w-full border px-3 py-2 rounded focus:outline-none focus:ring-2 focus:ring-yellow-600">
        </div>

        <div class="mb-6">
            <label class="block text-sm font-semibold text-gray-700 mb-1">Existencia</label>
            <input type="number" name="existencia" value="<?php echo e(old('existencia', $producto->existencia)); ?>" class="w-full border px-3 py-2 rounded focus:outline-none focus:ring-2 focus:ring-yellow-600">
        </div>

        <div class="flex items-center gap-4">
            <button type="submit" class="bg-yellow-600 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded flex items-center transition duration-300">
                <i data-lucide="save" class="w-4 h-4 mr-2"></i> Guardar
            </button>
            <a href="<?php echo e(route('productos.index')); ?>" class="text-gray-600 hover:underline flex items-center">
                <i data-lucide="arrow-left" class="w-4 h-4 mr-1"></i> Volver
            </a>
        </div>
    </form>

    
    <div class="hidden md:block animate-fade-in-up">
    <img src="<?php echo e(asset('img/ferreteria.jpg')); ?>" alt="Imagen Ferretería" class="w-full max-w-lg mx-auto rounded-xl shadow-lg">
    </div>
</div>


<style>
    @keyframes fadeInUp {
        0% {
            opacity: 0;
            transform: translateY(20px);
        }
        100% {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .animate-fade-in-up {
        animation: fadeInUp 0.8s ease-out both;
    }
</style>

<script>
    lucide.createIcons();
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\punto-venta\resources\views/productos/productos_edit.blade.php ENDPATH**/ ?>