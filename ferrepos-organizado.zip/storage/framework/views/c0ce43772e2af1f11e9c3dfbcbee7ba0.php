<?php $__env->startSection('contenido'); ?>
<h2 class="text-2xl font-bold text-gray-700 mb-4">Clientes</h2>


<a href="<?php echo e(route('clientes.create')); ?>" class="bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded font-semibold inline-block mb-4">
    <i data-lucide="user-plus" class="inline-block w-4 h-4 mr-1"></i> Agregar Cliente
</a>


<?php if(session('mensaje')): ?>
    <div 
        x-data="{ show: true }"
        x-show="show"
        x-transition
        x-init="setTimeout(() => show = false, 3000)"
        class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4"
    >
        <?php echo e(session('mensaje')); ?>

    </div>
<?php endif; ?>


<div class="overflow-x-auto bg-white shadow rounded-xl">
    <table class="min-w-full divide-y divide-gray-200 text-sm">
        <thead class="bg-yellow-500 text-white">
            <tr>
                <th class="px-6 py-3 text-left font-semibold">Nombre</th>
                <th class="px-6 py-3 text-left font-semibold">Teléfono</th>
                <th class="px-6 py-3 text-left font-semibold">Editar</th>
                <th class="px-6 py-3 text-left font-semibold">Eliminar</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100 text-gray-700">
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50 transition-all">
                    <td class="px-6 py-3"><?php echo e($cliente->nombre); ?></td>
                    <td class="px-6 py-3"><?php echo e($cliente->telefono); ?></td>
                    <td class="px-6 py-3">
                        <a href="<?php echo e(route('clientes.edit', $cliente)); ?>" class="text-blue-600 hover:underline flex items-center">
                            <i data-lucide="edit" class="w-4 h-4 mr-1"></i> Editar
                        </a>
                    </td>
                    <td class="px-6 py-3">
                        <form method="POST" action="<?php echo e(route('clientes.destroy', $cliente)); ?>" onsubmit="return confirm('¿Estás seguro de eliminar este cliente?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-600 hover:underline flex items-center">
                                <i data-lucide="trash-2" class="w-4 h-4 mr-1"></i> Eliminar
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\punto-venta\resources\views/clientes/clientes_index.blade.php ENDPATH**/ ?>