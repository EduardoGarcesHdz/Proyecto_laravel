<?php $__env->startSection('contenido'); ?>
<div class="flex flex-col md:flex-row items-center justify-between gap-6">
    
    <div class="w-full md:w-1/2">
        <h2 class="text-2xl font-bold text-gray-700 mb-4">Agregar Cliente</h2>

        
        <?php if($errors->any()): ?>
            <div class="bg-red-100 text-red-800 px-4 py-2 rounded mb-4">
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        
        <form method="POST" action="<?php echo e(route('clientes.store')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>

            <div>
                <label class="block text-gray-700 font-semibold mb-1" for="nombre">Nombre</label>
                <input type="text" name="nombre" id="nombre" placeholder="Nombre del cliente"
                    class="w-full p-2 border rounded-lg bg-gray-100 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                    required>
            </div>

            <div>
                <label class="block text-gray-700 font-semibold mb-1" for="telefono">Teléfono</label>
                <input type="text" name="telefono" id="telefono" placeholder="Teléfono"
                    class="w-full p-2 border rounded-lg bg-gray-100 focus:outline-none focus:ring-2 focus:ring-yellow-500">
            </div>

            <div class="flex items-center gap-4">
                <button type="submit"
                    class="bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded font-bold">
                    <i data-lucide="user-plus" class="inline-block w-4 h-4 mr-1"></i> Guardar
                </button>

                <a href="<?php echo e(route('clientes.index')); ?>"
                    class="text-gray-600 hover:underline flex items-center">
                    ← Volver al listado
                </a>
            </div>
        </form>
    </div>

    
    <div class="hidden md:block w-full md:w-1/2">
        <img src="<?php echo e(asset('img/clientes.png')); ?>" alt="Ferretería" class="rounded-xl shadow-md">
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\punto-venta\resources\views/clientes/clientes_create.blade.php ENDPATH**/ ?>