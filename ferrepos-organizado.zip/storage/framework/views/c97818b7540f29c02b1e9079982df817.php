<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="<?php echo e(env('APP_NAME')); ?>">
    <meta name="author" content="Parzibyte">
    <title><?php echo $__env->yieldContent("titulo"); ?> - <?php echo e(env('APP_NAME')); ?></title>
    <link href="<?php echo e(url('/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('/css/all.min.css')); ?>" rel="stylesheet">
    <style>
        body {
            padding-top: 70px;
            padding-bottom: 70px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
    <a class="navbar-brand" target="_blank" href="//parzibyte.me/blog"><?php echo e(env('APP_NAME')); ?></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse"
            id="botonMenu" aria-label="Mostrar u ocultar menú">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="menu">
        <ul class="navbar-nav mr-auto">
            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('register')); ?>">Registro</a>
                </li>
            <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Inicio&nbsp;<i class="fa fa-home"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('productos.index')); ?>">Productos&nbsp;<i class="fa fa-box"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('vender.index')); ?>">Vender&nbsp;<i class="fa fa-cart-plus"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('ventas.index')); ?>">Ventas&nbsp;<i class="fa fa-list"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('usuarios.index')); ?>">Usuarios&nbsp;<i class="fa fa-users"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('clientes.index')); ?>">Clientes&nbsp;<i class="fa fa-users"></i></a>
                </li>
            <?php endif; ?>
        </ul>
        <ul class="navbar-nav ml-auto">
            <?php if(auth()->guard()->check()): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('logout')); ?>" class="nav-link">
                        Salir (<?php echo e(Auth::user()->name); ?>)
                    </a>
                </li>
            <?php endif; ?>

            
            
        </ul>
    </div>
</nav>

<script type="text/javascript">
    document.addEventListener("DOMContentLoaded", () => {
        const menu = document.querySelector("#menu"),
              botonMenu = document.querySelector("#botonMenu");
        if (menu) {
            botonMenu.addEventListener("click", () => menu.classList.toggle("show"));
        }
    });
</script>

<main class="container-fluid">
    <?php echo $__env->yieldContent("contenido"); ?>
</main>

<footer class="px-2 py-2 fixed-bottom bg-dark">
    <span class="text-muted">
        Punto de venta en Laravel
        <i class="fa fa-code text-white"></i>
        con
        <i class="fa fa-heart" style="color: #ff2b56;"></i>
        por
        <a class="text-white" href="//parzibyte.me/blog">Parzibyte</a>
        &nbsp;|&nbsp;
        <a target="_blank" class="text-white" href="//github.com/parzibyte/sistema_ventas_laravel">
            <i class="fab fa-github"></i>
        </a>
    </span>
</footer>
</body>
</html>
<?php /**PATH C:\laragon\www\punto-venta\resources\views/maestra.blade.php ENDPATH**/ ?>