<?php

namespace App\Http\Controllers;

use App\Venta;
use Barryvdh\DomPDF\Facade\Pdf;

class PDFVentasController extends Controller
{
    public function generar($id)
    {
        $venta = Venta::with(['cliente', 'productos'])->findOrFail($id);

        $total = $venta->productos->sum(function ($producto) {
            return $producto->cantidad * $producto->precio;
        });

        $pdf = Pdf::loadView('ventas.factura_pdf', compact('venta', 'total'));
        return $pdf->download('factura_' . $venta->id . '.pdf');
    }
}
