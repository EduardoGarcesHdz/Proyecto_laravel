<?php

namespace App\Http\Controllers;

use App\User; // ✅ CORREGIDO AQUÍ
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class RegistroController extends Controller
{
    public function formulario()
    {
        return view('auth.register');
    }

    public function registrar(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|unique:users,email',
            'password' => 'required|string|min:6|confirmed',
            'rol' => 'required|in:admin,vendedor,cliente',
        ]);

        $user = new User(); // ya está bien
        $user->name = $request->name;
        $user->email = $request->email;
        $user->rol = $request->rol;
        $user->password = Hash::make($request->password);
        $user->save();

        return redirect()->route('login')->with('success', 'Usuario registrado correctamente.');
    }
}
