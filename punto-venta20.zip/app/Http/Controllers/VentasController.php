<?php

namespace App\Http\Controllers;

use App\Venta;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\Pdf;

class VentasController extends Controller
{
    public function index(Request $request)
    {
        $query = Venta::with('cliente')
            ->withSum('productos as total', DB::raw('cantidad * precio'));

        // Filtro por fecha exacta
        if ($request->filled('fecha')) {
            $query->whereDate('created_at', $request->fecha);
        }

        // Filtro por nombre del cliente (LIKE)
        if ($request->filled('cliente')) {
            $query->whereHas('cliente', function ($q) use ($request) {
                $q->where('nombre', 'like', '%' . $request->cliente . '%');
            });
        }

        $ventas = $query->get();

        return view('ventas.ventas_index', compact('ventas'));
    }

    public function ticket(Venta $venta)
    {
        $total = $venta->productos->sum(function ($producto) {
            return $producto->precio * $producto->cantidad;
        });

        $pdf = Pdf::loadView('ventas.ticket_pdf', compact('venta', 'total'));

        return $pdf->stream('ticket_venta_' . $venta->id . '.pdf');
    }

    public function show(Venta $venta)
    {
        $total = $venta->productos->sum(function ($producto) {
            return $producto->precio * $producto->cantidad;
        });

        return view("ventas.ventas_show", compact('venta', 'total'));
    }

    public function destroy(Venta $venta)
    {
        $venta->delete();

        return redirect()->route("ventas.index")
            ->with("mensaje", "Venta eliminada correctamente.");
    }
}



