<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ticket de Venta</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            color: #333;
            padding: 20px;
        }
        .container {
            max-width: 480px;
            margin: 0 auto;
        }
        .header {
            text-align: center;
            margin-bottom: 10px;
        }
        .logo {
            width: 100px;
            margin-bottom: 10px;
        }
        .titulo {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 4px;
        }
        .info {
            margin-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 12px;
        }
        th, td {
            padding: 6px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }
        th {
            background-color: #f5f5f5;
        }
        .total {
            text-align: right;
            font-size: 14px;
            font-weight: bold;
        }
        .footer {
            text-align: center;
            font-size: 11px;
            color: #777;
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <img src="{{ public_path('storage/logo.png') }}" alt="Logo Ferretería" class="logo">
        <div class="titulo">Ticket de Venta</div>
    </div>

    <div class="info">
        <strong>Fecha:</strong> {{ $venta->created_at->format('d/m/Y H:i') }}<br>
        <strong>Cliente:</strong> {{ $venta->cliente->nombre }}
    </div>

    <table>
        <thead>
            <tr>
                <th>Cantidad</th>
                <th>Producto</th>
                <th>Precio</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($venta->productos as $producto)
                <tr>
                    <td>{{ number_format($producto->cantidad, 2) }}</td>
                    <td>{{ $producto->descripcion }}</td>
                    <td>${{ number_format($producto->precio, 2) }}</td>
                    <td>${{ number_format($producto->cantidad * $producto->precio, 2) }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <div class="total">
        Total: ${{ number_format($total, 2) }}
    </div>

    <div class="footer">
        Gracias por su compra<br>
        © {{ date('Y') }} FerrePOS - Todos los derechos reservados
    </div>
</div>
</body>
</html>

