<?php $__env->startSection('contenido'); ?>
<h2 class="text-2xl font-bold text-gray-700 mb-4">Catálogo de Productos</h2>

<a href="<?php echo e(route('productos.create')); ?>" class="bg-yellow-600 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded mb-4 inline-block">
    <i data-lucide="plus-circle" class="inline-block w-5 h-5 mr-1"></i> Agregar Producto
</a>

<table class="min-w-full bg-white shadow-md rounded-xl overflow-hidden">
    <thead class="bg-yellow-500 text-white">
        <tr>
            <th class="py-3 px-4 text-left">Descripción</th>
            <th class="py-3 px-4 text-left">Código de Barras</th>
            <th class="py-3 px-4 text-left">Precio</th>
            <th class="py-3 px-4 text-left">Stock</th>
            <th class="py-3 px-4 text-left">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="border-b hover:bg-gray-50">
            <td class="py-3 px-4"><?php echo e($producto->descripcion); ?></td>
            <td class="py-3 px-4"><?php echo e($producto->codigo_barras); ?></td>
            <td class="py-3 px-4">$<?php echo e(number_format($producto->precio_venta, 2)); ?></td>
            <td class="py-3 px-4"><?php echo e($producto->existencia); ?></td>
            <td class="py-3 px-4 space-x-2">
                <a href="<?php echo e(route('productos.edit', $producto->id)); ?>" class="text-blue-600 hover:underline flex items-center">
                    <i data-lucide="pencil" class="w-4 h-4 mr-1"></i> Editar
                </a>
                <form action="<?php echo e(route('productos.destroy', $producto->id)); ?>" method="POST" class="inline-block">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" onclick="return confirm('¿Eliminar este producto?')" class="text-red-600 hover:underline flex items-center">
                        <i data-lucide="trash-2" class="w-4 h-4 mr-1"></i> Eliminar
                    </button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="5" class="text-center py-4 text-gray-500">No hay productos registrados.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

<script>
    lucide.createIcons();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\punto-venta\resources\views/productos/productos_index.blade.php ENDPATH**/ ?>